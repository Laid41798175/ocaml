(* simple let val *)

let val f = fn x => (x + 1) in 
  f 2
end


(* result : int *)
